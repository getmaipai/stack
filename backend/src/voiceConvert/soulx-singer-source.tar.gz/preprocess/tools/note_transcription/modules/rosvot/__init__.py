"""Core ROSVOT model components."""
