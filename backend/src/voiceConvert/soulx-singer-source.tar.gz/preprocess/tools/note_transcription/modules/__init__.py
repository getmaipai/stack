"""ROSVOT model submodules."""
