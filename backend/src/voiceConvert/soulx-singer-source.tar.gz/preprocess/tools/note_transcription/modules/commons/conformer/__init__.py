"""Conformer layers for ROSVOT."""
